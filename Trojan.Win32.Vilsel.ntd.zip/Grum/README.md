# Grum
The Grum Spam Bot

Uploaded to GitHub for those want to analyse the code.
