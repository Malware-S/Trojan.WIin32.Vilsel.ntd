<?php
//******************** Database

$db_host="localhost";			// Database parameters
$db_user="root";
$db_pass="555888";
$database="spm";
?>