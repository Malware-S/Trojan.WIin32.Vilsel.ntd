<?
    
    header("Location: http://traffic-acc.com/spm/admin/index.php");
    
?>

